<?php

namespace App\Http\Controllers\Inventory;

//use App\Models\Inventory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Str;
use DB;
use PDF;
use Response;


class InventoryController extends Controller
{

    public function index()
    {
        //$blogs = Bolgs::all();
        //return view('blogs.blog', ['blogs' => $blogs]);
    }

    //brand
    public function brand()
    {
        return view('frontend.inventory.brand');
    }

    //addBrand
    public function addBrand(){
        return view('frontend.inventory.brand_add');
    }

    //editBrand
    public function editBrand($id){
        $brand = DB::table('brand')->where('id', $id)->first();
        return view('frontend.inventory.brand_edit',
        [
               'brand'=>$brand 
        ]);
    }

    //addEditBrandProcess
    public function addEditBrandProcess(Request $request){
        if ($request->method() == 'POST') {
            
            $id = $request->id;
            $brand_name = $request->brand_name;
            $brand_description = $request->brand_description;
            $brand_status = $request->brand_status;
            
            
            if( Auth::guard('frontpharmacy')->user() ){
                $phparmacy_id = Auth::guard('frontpharmacy')->user()->id;
            }else{
                $phparmacy_id = 0;
            }
            
            if($id == ''){
                //add Brand
                    $brand_data = [
                        'name'=>$brand_name,
                        'slug'=>Str::slug($brand_name),
                        'description'=>$brand_description,
                        'pharmacy_id' =>$phparmacy_id,
                        'status'=>$brand_status,
                    ];    
                    //echo '<pre>';
                    //print_r($brand_data);
                    //die;
                    DB::table('brand')->insert($brand_data);

                    Session::flash('message', 'Brand Added Successfully!');
                    Session::flash('alert-class', 'alert-success');
                    return redirect('frontpharmacy/inventory/brand');

                }else{
                //edit Brand
                $brand_data = [
                    'name'=>$brand_name,
                    'slug'=>Str::slug($brand_name),
                    'description'=>$brand_description,
                    'pharmacy_id' =>$phparmacy_id,
                    'status'=>$brand_status,
                ];    
                DB::table('brand')->where('id', $id)->update($brand_data);

                Session::flash('message', 'Brand Updated successfully!');
                Session::flash('alert-class', 'alert-success');
                return redirect('frontpharmacy/inventory/brand');
            }
        }
    }

    //category
    public function category()
    {
        return view('frontend.inventory.category');
    }

    //addCategory
    public function addCategory(){
        return view('frontend.inventory.category_add');
    }

    //editCategory
    public function editCategory($id){
        $category = DB::table('category')->where('id', $id)->first();
        return view('frontend.inventory.category_edit',
        [
               'category'=>$category 
        ]);
    }

    //addEditCategoryProcess
    public function addEditCategoryProcess(Request $request){
        if ($request->method() == 'POST') {
            
            $id = $request->id;
            $category_parent = $request->category_parent;
            $category_name = $request->category_name;
            $category_description = $request->category_description;
            $category_status = $request->category_status;
            
            
            if( Auth::guard('frontpharmacy')->user() ){
                $phparmacy_id = Auth::guard('frontpharmacy')->user()->id;
            }else{
                $phparmacy_id = 0;
            }
            
            if($id == ''){
                //add Category
                    $category_data = [
                        'parent_id' => $category_parent,
                        'name'=>$category_name,
                        'slug'=>Str::slug($category_name),
                        'description'=>$category_description,
                        'pharmacy_id' =>$phparmacy_id,
                        'status'=>$category_status,
                    ];    
                    DB::table('category')->insert($category_data);

                    Session::flash('message', 'Category Added Successfully!');
                    Session::flash('alert-class', 'alert-success');
                    return redirect('frontpharmacy/inventory/category');

                }else{
                //edit Category
                $category_data = [
                    'parent_id' => $category_parent,
                    'name'=>$category_name,
                    'slug'=>Str::slug($category_name),
                    'description'=>$category_description,
                    'pharmacy_id' =>$phparmacy_id,
                    'status'=>$category_status,
                ];    
                DB::table('category')->where('id', $id)->update($category_data);

                Session::flash('message', 'Category Updated successfully!');
                Session::flash('alert-class', 'alert-success');
                return redirect('frontpharmacy/inventory/category');
            }
        }
    }


    //product
    public function product()    {
        return view('frontend.inventory.product');
    }


    //addProduct
    public function addProduct(){
        return view('frontend.inventory.product_add');
    }

    //editProduct
    public function editProduct($id){
        $product = DB::table('product')->where('id', $id)->first();
        return view('frontend.inventory.product_edit',
        [
               'product'=>$product 
        ]);
    }

    //addEditProductProcess
    public function addEditProductProcess(Request $request){
        if ($request->method() == 'POST') {
            
            $id = $request->id;
            $product_name = $request->product_name;
            $product_price = $request->product_price;
            $product_quantity = $request->product_quantity;
            $product_description = $request->product_description;
            $product_status = $request->product_status;
            $product_cat = $request->product_cat;
            $product_brand = $request->product_brand;

            $product_cat_arr = explode('_', $product_cat);
            
            
            if( Auth::guard('frontpharmacy')->user() ){
                $phparmacy_id = Auth::guard('frontpharmacy')->user()->id;
            }else{
                $phparmacy_id = 0;
            }
            
            if($id == ''){
                //add Product
                    $product_data = [
                        'name'=>$product_name,
                        'slug'=>Str::slug($product_name),
                        'brand_id'=>$product_brand,
                        'main_cat'=>$product_cat_arr[0],
                        'sub_cat'=>$product_cat_arr[1],
                        'description'=>$product_description,
                        'pharmacy_id' =>$phparmacy_id,
                        'status'=>$product_status,
                    ];    
                    //echo '<pre>';
                    //print_r($product_data);
                    //die;
                    DB::table('product')->insert($product_data);

                    Session::flash('message', 'Product Added Successfully!');
                    Session::flash('alert-class', 'alert-success');
                    return redirect('frontpharmacy/inventory/product');

                }else{
                //edit Product
                $product_data = [
                    'name'=>$product_name,
                    'slug'=>Str::slug($product_name),
                    'brand_id'=>$product_brand,
                    'main_cat'=>$product_cat_arr[0],
                    'sub_cat'=>$product_cat_arr[1],
                    'price'=>$product_price,
                    'quantity'=>$product_quantity,
                    'description'=>$product_description,
                    'pharmacy_id' =>$phparmacy_id,
                    'status'=>$product_status,
                ];    
                DB::table('product')->where('id', $id)->update($product_data);

                Session::flash('message', 'Product Updated successfully!');
                Session::flash('alert-class', 'alert-success');
                return redirect('frontpharmacy/inventory/product');
            }
        }
    }
    

    //makeOrder
    public function makeOrder()
    {
        return view('frontend.inventory.make_order');
    }

    

    


}//end of class InventoryController
