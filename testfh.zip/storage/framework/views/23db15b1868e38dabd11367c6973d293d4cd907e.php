<?php $__env->startSection('doctors'); ?>
    active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
            <div class="container-fluid">
			
                <div class="row">
					<div class="col-xl-3 col-xxl-3 col-sm-6">
						<div class="widget-stat card bg-primary ">
                            <div class="media" style="margin: 20px;">
                                <span class="mr-3">
                                    <i class="fa fa-user-md"></i>
                                </span>
                                <div class="media-body text-white">
                                     <a href="" style="color: white;text-align: center"><p class="mb-1"><strong> Total Doctor</strong></p></a>
                                    <h3 class="text-white" style="text-align: center"><?php echo e($doctorsCount); ?> </h3>                           
                                </div>
                            </div>
						</div>
					</div>
                    <div class="col-xl-3 col-xxl-3 col-sm-6">
						<div class="widget-stat card bg-primary ">
                            <div class="media" style="margin: 20px;">
                                <span class="mr-3">
                                    <i class="fa fa-wheelchair"></i>
                                </span>
                                <div class="media-body text-white">
                                     <a href="" style="color: white;text-align: center"><p class="mb-1"><strong> Total Patient</strong></p></a>
                                    <h3 class="text-white" style="text-align: center"><?php echo e($patientsCount); ?></h3>                           
                                </div>
                            </div>
						</div>
					</div>

                    <div class="col-xl-3 col-xxl-3 col-sm-6">
						<div class="widget-stat card bg-primary ">
                            <div class="media" style="margin: 20px;">
                                <span class="mr-3">
                                    <i class="fa fa-calendar"></i>
                                </span>
                                <div class="media-body text-white">
                                     <a href="" style="color: white;text-align: center"><p class="mb-1"><strong> Total Appointment</strong></p></a>
                                    <h3 class="text-white" style="text-align: center"><?php echo e($appointmentsCount); ?></h3>                           
                                </div>
                            </div>
						</div>
					</div>

                    <div class="col-xl-3 col-xxl-3 col-sm-6">
						<div class="widget-stat card bg-primary ">
                            <div class="media" style="margin: 20px;">
                                <span class="mr-3">
                                    <i class="fas fa-hospital"></i>
                                </span>
                                <div class="media-body text-white">
                                     <a href="" style="color: white;text-align: center"><p class="mb-1"><strong> Total Hospital</strong></p></a>
                                    <h3 class="text-white" style="text-align: center"><?php echo e($hospitalsCount); ?></h3>                           
                                </div>
                            </div>
						</div>
					</div>

                    <div class="col-xl-3 col-xxl-3 col-sm-6">
						<div class="widget-stat card bg-primary ">
                            <div class="media" style="margin: 20px;">
                                <span class="mr-3">
                                    <i class="fa-solid fa-flask"></i>
                                </span>
                                <div class="media-body text-white">
                                     <a href="" style="color: white;text-align: center"><p class="mb-1"><strong> Total Lab</strong></p></a>
                                    <h3 class="text-white" style="text-align: center"><?php echo e($labsCount); ?> </h3>                           
                                </div>
                            </div>
						</div>
					</div>

                    <div class="col-xl-3 col-xxl-3 col-sm-6">
						<div class="widget-stat card bg-primary ">
                            <div class="media" style="margin: 20px;">
                                <span class="mr-3">
                                    <i class="fa-solid fa-house-chimney-crack"></i>
                                </span>
                                <div class="media-body text-white">
                                     <a href="" style="color: white;text-align: center"><p class="mb-1"><strong> Total Dawakhana</strong></p></a>
                                    <h3 class="text-white" style="text-align: center"></h3>                           
                                </div>
                            </div>
						</div>
					</div>
                  
                    <div class="col-xl-3 col-xxl-3 col-sm-6">
						<div class="widget-stat card bg-primary ">
                            <div class="media" style="margin: 20px;">
                                <span class="mr-3">
                                    <i class="fa-solid fa-user-nurse"></i>
                                </span>
                                <div class="media-body text-white">
                                     <a href="" style="color: white;text-align: center"><p class="mb-1"><strong> Total Nurse</strong></p></a>
                                    <h3 class="text-white" style="text-align: center"><?php echo e($nursesCount); ?></h3>                           
                                </div>
                            </div>
						</div>
					</div>
                  
				</div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\testfh\resources\views/dashboard/admin/dashboard.blade.php ENDPATH**/ ?>